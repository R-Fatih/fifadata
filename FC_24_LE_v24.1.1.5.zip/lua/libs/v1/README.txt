Old Lua API.
Please, use v2